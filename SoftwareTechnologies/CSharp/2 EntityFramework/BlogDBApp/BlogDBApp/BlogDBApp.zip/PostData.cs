﻿namespace BlogDBApp
{
    internal class PostData
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public System.DateTime Date { get; set; }
    }
}